---
title: "Appréciation de la contribution — Guide d'utilisation"
subtitle: "Mise à jour du 7 novembre 2026 (version 1.0.0.9) · Pour les personnes en appréciation et les gestionnaires"
lang: fr-CA
---

# En bref

L'appréciation de la contribution se fait maintenant **dans une application**, et non plus dans un document Word.

- **Un seul dossier** par appréciation, conservé dans SharePoint de la Ville.
- **Vous ne voyez que vos dossiers** : ceux où vous êtes la personne en appréciation, son supérieur ou son directeur de service.
- **L'application avise automatiquement** la bonne personne à chaque étape, par courriel.
- **Aucun fichier à envoyer** par courriel.

**Pour ouvrir l'application :** *[lien de l'application]*. Vous pouvez l'ajouter à vos favoris. Elle s'ouvre dans votre navigateur, avec votre compte de la Ville, sans mot de passe à créer.

![Le circuit d'une appréciation](1-Circuit-des-etapes.png)

# 1. L'écran « Mes dossiers »

C'est l'écran d'accueil. Vous y voyez **toutes les appréciations qui vous concernent**, avec votre rôle, le statut et la date de la dernière modification.

| Élément | À quoi il sert |
|---|---|
| **Rechercher un nom** | Trouver un dossier par le nom de la personne |
| **Tous · En cours · À approuver par moi · Complétés** | Filtrer la liste. **« À approuver par moi »** montre les dossiers qui attendent **votre** action |
| **Ouvrir** | Ouvrir le dossier |
| **📝 Nouveau formulaire** | Commencer **votre** appréciation (personne en appréciation seulement) |

# 2. Personne en appréciation : vos étapes

## Étape 1 — Commencer et remplir

1. Cliquez sur **📝 Nouveau formulaire**.
2. En haut à gauche, **« Vous êtes »** indique **Personne en appréciation**.
3. Choisissez votre **type de poste** :
   - **Cadre avec équipe** ;
   - **Cadre sans équipe** ;
   - **Professionnel non syndiqué**.

   L'application affiche le formulaire qui correspond.
4. Vérifiez l'**identification**. Votre nom et votre poste sont proposés automatiquement : corrigez-les au besoin. Inscrivez votre **ID** et cochez le **type de rencontre**.
5. Remplissez les sections :
   - **A** : vos objectifs de l'année en cours et de l'année à venir. Utilisez **+ Ajouter une ligne** au besoin.
   - **B** : vos postures de leadership (cadres) ou vos compétences (professionnels), avec vos cotes et vos exemples.
   - **C** : cochez les thèmes ayant fait l'objet d'actions particulières, et donnez des exemples.
   - **D** : vos actions de développement passées et vos nouveaux besoins.
   - **F** : votre bilan de l'année.
6. Cliquez sur **☁️ Enregistrer et déposer**. Un message vert confirme l'enregistrement.

> 💡 **Enregistrez souvent.** Vous pouvez fermer l'application et revenir plus tard : ouvrez le dossier dans **Mes dossiers**. Votre **supérieur(e) immédiat(e)** et votre **supérieur(e) hiérarchique** sont trouvés automatiquement dans l'annuaire, au premier enregistrement.

> ❓ Le bouton **Comment remplir ce formulaire** (en haut à gauche) explique chaque section en 2 minutes.

## Étape 2 — Aviser votre supérieur(e)

Quand votre partie est prête :

1. Allez à la **section G**.
2. Cliquez sur le bouton **Aviser**.

Votre supérieur(e) immédiat(e) reçoit un courriel avec un lien vers votre dossier. **Vous pouvez encore modifier** votre contenu ensuite.

## Étape 3 — La version de votre supérieur(e), puis la rencontre

Votre supérieur(e) immédiat(e) remplit sa partie (cotes de la section B, bilan de la section E, évaluation globale) et vous la **transmet** : vous recevez le courriel « la version de votre supérieur(e) immédiat(e) est prête » et pouvez la consulter avant la rencontre.

> Tant que cette version n'est pas transmise, la case de confirmation indique « En attente de la version de votre supérieur(e) immédiat(e) » et le bouton **Approuver et soumettre** reste grisé.

### La rencontre

Vous échangez avec votre supérieur(e). Ajustez votre dossier au besoin, puis **enregistrez**.

**Si un directeur ou une directrice de service doit approuver :** dans la section G, cochez **« Approbation du directeur / de la directrice de service requise »** et choisissez la personne. Ce choix est possible jusqu'à la confirmation.

## Étape 4 — Approuver et soumettre

Après la rencontre :

1. Dans la **section G**, cochez « Je confirme avoir pris connaissance du contenu de ce formulaire et je l'approuve ».
2. Cliquez sur **Approuver et soumettre**.

**À partir de ce moment, votre contenu est verrouillé.** Votre supérieur(e) immédiat(e) reçoit « À approuver ».

## Ensuite

Vous suivez l'avancement dans la **barre d'étapes**, en haut du formulaire. Quand le dossier est **Complété** :

- vous recevez un courriel ;
- le dossier passe en **lecture seule** ;
- vous pouvez en tout temps produire le **PDF**.

# 3. Supérieur(e) immédiat(e)

1. Vous recevez un **courriel** : « prête pour votre consultation » après l'avis, puis « À approuver » après la confirmation. Cliquez sur le lien, ou ouvrez **Mes dossiers › À approuver par moi**.
2. L'application reconnaît votre rôle **automatiquement** : « Vous êtes : Supérieur(e) immédiat(e) ».
3. **Avant la rencontre**, remplissez votre partie :
   - **vos cotes** dans la section B (colonne du supérieur) ;
   - le **bilan annuel (section E)** ;
   - l'**évaluation globale**.

   Vous pouvez aussi compléter l'identification et les sections A, C et D.
4. **Transmettez votre version :** dans la **section G**, carte « Supérieur(e) immédiat(e) », cochez « Ma version est complète… », puis cliquez sur **📨 Transmettre ma version**. La personne reçoit un courriel et voit maintenant vos cotes, votre bilan et l'évaluation globale.
5. **Tenez la rencontre.** Vous pouvez encore ajuster votre partie.
6. Après la rencontre, la personne clique sur **Approuver et soumettre** ; vous recevez « À approuver ».
7. Dans la **section G**, cochez la case et cliquez sur **Approuver**. Le supérieur hiérarchique reçoit alors « À approuver ».

# 4. Supérieur(e) hiérarchique et directeur ou directrice de service

1. Vous recevez « À approuver » par courriel, avec le lien vers le dossier.
2. Prenez connaissance du dossier. La **barre d'étapes** montre où il en est, et **🖨️ Aperçu PDF** en donne une version complète à lire.
3. Dans la **section G**, cochez la case de confirmation et cliquez sur **Approuver**.

- **Sans directeur de service requis :** l'approbation du supérieur hiérarchique **termine** le dossier (statut « Complété »).
- **Avec directeur de service requis :** le directeur ou la directrice de service reçoit « À approuver » et approuve en dernier.

**À « Complété », tout est automatique :**

- l'évaluation globale est transmise aux **RH** ;
- tout le monde est avisé ;
- le dossier passe en **lecture seule**.

![Qui remplit quoi](2-Qui-remplit-quoi.png)

# 5. Les outils pratiques

| Outil | Où | À quoi il sert |
|---|---|---|
| **Barre d'étapes** | En haut du formulaire | Les 8 étapes, avec un ✓ et la date quand elles sont faites |
| **🖨️ Aperçu PDF** | Barre de gauche | Produit le **PDF complet** de l'appréciation (10 à 30 secondes) et le **joint au dossier**. Cliquez ensuite sur **📄 Ouvrir le PDF** |
| **🗑️ Nouveau formulaire** | Barre de gauche | Vide l'écran pour commencer un autre formulaire. Ce qui a été enregistré n'est pas effacé |
| **📂 Mes dossiers** | Barre de gauche | Revenir à la liste de vos dossiers |

# 6. Questions fréquentes

| Question | Réponse |
|---|---|
| Je ne vois pas le dossier de mon employé. | Il apparaît dès que la personne a fait son premier **Enregistrer et déposer**. Vérifiez aussi le filtre **Tous**. |
| Mon supérieur immédiat affiché n'est pas le bon. | Il vient de l'annuaire de la Ville. Écrivez au soutien (en bas de page) pour faire corriger le dossier. |
| Je ne peux plus modifier mon contenu. | Il est verrouillé depuis la **confirmation**. Pour une correction, parlez-en à votre supérieur(e) et au soutien RH. |
| Une section est grisée. | Elle est réservée à un autre rôle, ou à une autre étape. |
| Le bouton Approuver est grisé. | Cochez d'abord la case de confirmation juste au-dessus. |
| « Approuver et soumettre » est grisé (personne en appréciation). | Votre supérieur(e) immédiat(e) n'a pas encore transmis sa version. Vous recevrez un courriel dès qu'elle sera prête. |
| Mon ID n'est pas rempli automatiquement. | C'est normal : inscrivez votre numéro d'employé. Il est obligatoire pour enregistrer. |
| Comment corriger mes fautes d'orthographe ? | Dans Edge : Paramètres › Langues › activez la vérification orthographique et ajoutez Français (Canada). Les fautes sont soulignées en rouge. |
| Le PDF ne s'ouvre pas. | Attendez le message vert, puis cliquez sur **📄 Ouvrir le PDF**. Si un message rouge apparaît, réessayez dans une minute, puis contactez le soutien. |
| Il y a plusieurs versions de mon PDF ? | Non : chaque nouvelle demande remplace l'ancienne. Le PDF le plus récent est toujours celui joint au dossier. |
| Qui voit mon appréciation ? | Vous, votre supérieur(e) immédiat(e), votre supérieur(e) hiérarchique, le directeur ou la directrice de service si requis, et l'équipe RH responsable. **Personne d'autre.** |
| Est-ce que le courriel contient mon évaluation ? | Non. Les courriels contiennent seulement un lien. Seule l'**évaluation globale** est transmise aux RH, à la fin. |

# 7. Besoin d'aide ?

- Cliquez sur **❓ Comment remplir ce formulaire** (en haut à gauche), puis sur le bouton de contact pour écrire à l'équipe.
- Soutien RH : *[adresse de soutien]*.
